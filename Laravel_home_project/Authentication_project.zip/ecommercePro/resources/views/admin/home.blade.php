<x-app-layout>
  <h1>Admin HOME</h1>
</x-app-layout>
